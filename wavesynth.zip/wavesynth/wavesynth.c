// Adapted from: AWG_1.c Arbitary Waveform Generator C Program, by LifeWithDavid https://github.com/LifeWithDavid/Raspberry-Pi-Pico-PIO/blob/44e7c03eb1e3248dd14ff50a15d8dbd1ba16ddb9/EP%2014%20AWG%20Files.txt


#include <stdio.h>
#include <math.h>
#include "pico/stdlib.h"
#include "hardware/dma.h"
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/gpio.h"
#include "wavesynth.pio.h"
#define PI 3.14159265358979323846

#define AM_REC 21 //gpio 21

PIO pio = pio0;
uint sm = 0;

typedef struct{
	float DIV_HIGH;
	float DIV_LOW;
} FSK_divisors;

FSK_divisors divisors;

void gpio_irq_callback(uint gpio, uint32_t events); 

void gpio_init_setup() {
    gpio_init(AM_REC);
    gpio_set_dir(AM_REC, GPIO_IN);
    gpio_pull_down(AM_REC); 
}

void setup_gpio_interrupts() {
    gpio_set_irq_enabled_with_callback(AM_REC, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &gpio_irq_callback);
}

void gpio_irq_callback(uint gpio, uint32_t events) {
    if (gpio == AM_REC) {
		bool is_high = gpio_get(AM_REC);
        float new_div = is_high ? divisors.DIV_HIGH : divisors.DIV_LOW;
        pio_sm_set_clkdiv(pio, sm, new_div);
    }
}

int main()
{
	stdio_init_all(); 
	gpio_init_setup();
	setup_gpio_interrupts();

	uint LSB_PIN = 8; //Start of output pin group
	uint NUM_PINS = 8; //Number of output pins
	uint bufdepth=4096;

	float factor;
	uint numperiods;

	uint SM_CLK_FREQ_H;
	uint SM_CLK_FREQ_L;

    uint8_t wavebuff[4096] __attribute__((aligned(4096)));
 	
	uint freq_high = 20000;
	uint freq_low = 20000;//21500;
	
	uint wave_offset = 128; //3.3v = 255 -> 128 +- 127
	uint wave_amplitude = 127;
	
	//Reduce resolution for higher frequencies
	if (freq_low > 50000) {
		numperiods = 64 ;
		SM_CLK_FREQ_H = (float) freq_high * bufdepth / numperiods ;
		SM_CLK_FREQ_L = (float) freq_low * bufdepth / numperiods ;
	}
	else {
		numperiods = 16;
		SM_CLK_FREQ_H = (float) freq_high * bufdepth / numperiods ;
		SM_CLK_FREQ_L = (float) freq_low * bufdepth / numperiods ;	
	}

	for (int i = 0; i < bufdepth; ++i) {
		factor=(float)numperiods*i/bufdepth;
		wavebuff[i] = wave_offset+(sin((factor)*2*PI)*wave_amplitude);
	}	

	uint offset = pio_add_program(pio, &pio_byte_out_program);

	divisors.DIV_HIGH = calculate_divisor(SM_CLK_FREQ_H);
	divisors.DIV_LOW = calculate_divisor(SM_CLK_FREQ_L);

    pio_byte_out_program_init(pio, sm, offset, LSB_PIN, NUM_PINS, divisors.DIV_LOW);

	int dma_ch1 = dma_claim_unused_channel(true);
    int dma_ch2 = dma_claim_unused_channel(true);
				
    dma_channel_config dma_ch1_config = dma_channel_get_default_config(dma_ch1);
	channel_config_set_chain_to(&dma_ch1_config, dma_ch2);
    channel_config_set_dreq(&dma_ch1_config, DREQ_PIO0_TX0);
	channel_config_set_ring(&dma_ch1_config, false, 12);
	
    dma_channel_config dma_ch2_config = dma_channel_get_default_config(dma_ch2);
	channel_config_set_chain_to(&dma_ch2_config, dma_ch1);
	channel_config_set_dreq(&dma_ch2_config, DREQ_PIO0_TX0);
	channel_config_set_ring(&dma_ch2_config, false, 12);
	
    dma_channel_configure(
        dma_ch1,
        &dma_ch1_config,
        &pio0_hw->txf[sm],
        wavebuff,
        bufdepth,
        false
	);

    dma_channel_configure(
        dma_ch2,
        &dma_ch2_config,
        &pio0_hw->txf[sm],
        wavebuff,
        bufdepth,
        false
    );

    dma_start_channel_mask(1u << dma_ch1);

	sleep_ms(50000);
	//Keep the main core "active" to keep the program running...
	while(true) {
		sleep_ms(5000);
    }
}